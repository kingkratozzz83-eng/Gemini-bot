package com.gemini.wabot

import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.util.Rational
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ProgressBar
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: BotPrefsManager
    private var lastSessionsSignature: String = ""
    private var bgMediaPlayer: MediaPlayer? = null
    private var bgSurface: Surface? = null
    private var latestPairCodeForPip: String = ""
    private var hasPlayedWelcomeThisSession: Boolean = false

    private val modelList = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-pro",
        "gemini-2.5-flash-lite",
        "gemini-3.8-flash",
        "gemini-3.5-flash-lite",
        "gemini-4-argon"
    )

    private val scopeLabels = listOf(
        "Chat Pribadi Otomatis + Grup via /bot-active",
        "Hanya Chat Pribadi (Grup Nonaktif)",
        "Hanya Grup yang Diaktifkan (/bot-active)"
    )
    private val scopeValues = listOf("all", "private", "group")
    private val menuStyleLabels = listOf(
        "🗂️ Menu List Interaktif + Teks (Keduanya Aktif)",
        "🗂️ Khusus Popup Menu List Interaktif (Tombol Pilih)",
        "📝 Khusus Menu Teks Biasa"
    )
    private val menuStyleValues = listOf("both", "list", "text")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BotPrefsManager(this)

        if (prefs.loggedInEmail.isEmpty()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        val textureVideoBg: TextureView = findViewById(R.id.textureVideoBg)
        val switchUnsafeScreenShare: SwitchMaterial = findViewById(R.id.switchUnsafeScreenShare)
        val btnToggleBgAudio: Button = findViewById(R.id.btnToggleBgAudio)

        setupVideoBackgroundLoop(textureVideoBg, btnToggleBgAudio)

        switchUnsafeScreenShare.isChecked = prefs.isUnsafeScreenShare
        applyScreenShareMode(prefs.isUnsafeScreenShare)
        switchUnsafeScreenShare.setOnCheckedChangeListener { _, isUnsafe ->
            prefs.isUnsafeScreenShare = isUnsafe
            applyScreenShareMode(isUnsafe)
            val msg = if (isUnsafe) {
                "🔓 Mode Tidak Aman AKTIF: Layar & Video sekarang tetap terlihat saat Berbagi Layar (Screen Share)!"
            } else {
                "🔒 Mode Aman AKTIF: Layar disembunyikan saat Berbagi Layar."
            }
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }

        val tvLoggedInAccount: TextView = findViewById(R.id.tvLoggedInAccount)
        val btnSwitchAccount: Button = findViewById(R.id.btnSwitchAccount)
        val btnExitApp: Button = findViewById(R.id.btnExitApp)

        val tvEngineStatus: TextView = findViewById(R.id.tvEngineStatus)
        val tvStatsBadge: TextView = findViewById(R.id.tvStatsBadge)
        val switchMasterBot: SwitchMaterial = findViewById(R.id.switchMasterBot)
        val rgConnectionMode: RadioGroup = findViewById(R.id.rgConnectionMode)
        val rbModeLocal: RadioButton = findViewById(R.id.rbModeLocal)
        val rbModeVps: RadioButton = findViewById(R.id.rbModeVps)
        val layoutVpsConfig: LinearLayout = findViewById(R.id.layoutVpsConfig)
        val etVpsUrl: EditText = findViewById(R.id.etVpsUrl)
        val etVpsUser: EditText = findViewById(R.id.etVpsUser)
        val etVpsSshPort: EditText = findViewById(R.id.etVpsSshPort)
        val etVpsSecret: EditText = findViewById(R.id.etVpsSecret)
        val btnConnectVpsNow: Button = findViewById(R.id.btnConnectVpsNow)
        val btnCheckVpsSsh: Button = findViewById(R.id.btnCheckVpsSsh)
        val btnRestartVpsSsh: Button = findViewById(R.id.btnRestartVpsSsh)
        val btnDisableBatteryOpt: Button = findViewById(R.id.btnDisableBatteryOpt)

        val etPhoneNumber: EditText = findViewById(R.id.etPhoneNumber)
        val btnGetPairingCode: Button = findViewById(R.id.btnGetPairingCode)
        val tvPairingCodeResult: TextView = findViewById(R.id.tvPairingCodeResult)
        val btnCopyPairingCode: Button = findViewById(R.id.btnCopyPairingCode)
        val btnEnterPipMode: Button = findViewById(R.id.btnEnterPipMode)
        val layoutPairedSessionsList: LinearLayout = findViewById(R.id.layoutPairedSessionsList)
        val btnOpenWaWeb: Button = findViewById(R.id.btnOpenWaWeb)

        val switchLockApiKey: SwitchMaterial = findViewById(R.id.switchLockApiKey)
        val etBotName: EditText = findViewById(R.id.etBotName)
        val etGeminiApiKey: EditText = findViewById(R.id.etGeminiApiKey)
        val tvApiKeyLockHint: TextView = findViewById(R.id.tvApiKeyLockHint)
        val spinnerGeminiModel: Spinner = findViewById(R.id.spinnerGeminiModel)
        val btnPresetSantai: Button = findViewById(R.id.btnPresetSantai)
        val btnPresetToko: Button = findViewById(R.id.btnPresetToko)
        val btnPresetPintar: Button = findViewById(R.id.btnPresetPintar)
        val etSystemPrompt: EditText = findViewById(R.id.etSystemPrompt)

        val spinnerReplyScope: Spinner = findViewById(R.id.spinnerReplyScope)
        val spinnerMenuStyle: Spinner = findViewById(R.id.spinnerMenuStyle)
        val etGroupTrigger: EditText = findViewById(R.id.etGroupTrigger)
        val etBlacklistNumbers: EditText = findViewById(R.id.etBlacklistNumbers)
        val btnSaveConfig: Button = findViewById(R.id.btnSaveConfig)
        val btnTestGemini: Button = findViewById(R.id.btnTestGemini)
        val btnResetMemory: Button = findViewById(R.id.btnResetMemory)
        val tvLiveLogs: TextView = findViewById(R.id.tvLiveLogs)

        val lockBadge = if (prefs.ownerLockedEmail.isNotEmpty()) " 🔒" else ""
        tvLoggedInAccount.text = "👤 ${prefs.loggedInEmail}$lockBadge"

        btnSwitchAccount.setOnClickListener {
            prefs.loggedInEmail = ""
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        btnExitApp.setOnClickListener {
            showExitOptionsDialog()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                showExitOptionsDialog()
            }
        })

        spinnerGeminiModel.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modelList
        )
        spinnerReplyScope.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            scopeLabels
        )
        spinnerMenuStyle.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            menuStyleLabels
        )

        switchMasterBot.isChecked = prefs.isBotEnabled
        if (prefs.connectionMode == "VPS") {
            rbModeVps.isChecked = true
            layoutVpsConfig.visibility = View.VISIBLE
        } else {
            rbModeLocal.isChecked = true
            layoutVpsConfig.visibility = View.GONE
        }

        etVpsUrl.setText(BotEngineClient.extractHostFromUrl(prefs.vpsUrl))
        etVpsUser.setText(prefs.vpsUser)
        etVpsSshPort.setText(prefs.vpsSshPort)
        etVpsSecret.setText(prefs.vpsSecret)
        etPhoneNumber.setText(prefs.phoneNumber)
        etBotName.setText(prefs.botName)
        etGeminiApiKey.setText(prefs.geminiApiKey)
        playWelcomeCinematicIfNeeded()
        etSystemPrompt.setText(prefs.systemPrompt)
        etGroupTrigger.setText(prefs.groupTrigger)
        etBlacklistNumbers.setText(prefs.blacklistNumbers)

        val savedModel = prefs.geminiModel
        val modelIdx = modelList.indexOf(savedModel).let { if (it >= 0) it else 0 }
        if (prefs.geminiModel != modelList[modelIdx]) {
            prefs.geminiModel = modelList[modelIdx]
        }
        spinnerGeminiModel.setSelection(modelIdx, false)

        val scopeIdx = scopeValues.indexOf(prefs.replyScope).coerceAtLeast(0)
        spinnerReplyScope.setSelection(scopeIdx, false)
        val menuIdx = menuStyleValues.indexOf(prefs.menuStyle).coerceAtLeast(0)
        spinnerMenuStyle.setSelection(menuIdx, false)

        spinnerGeminiModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenModel = modelList.getOrElse(position) { "gemini-2.5-flash" }
                if (prefs.geminiModel != chosenModel) {
                    prefs.geminiModel = chosenModel
                    startBotService()
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                    Toast.makeText(this@MainActivity, "✅ Model AI diubah ke: $chosenModel", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerReplyScope.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenScope = scopeValues.getOrElse(position) { "all" }
                if (prefs.replyScope != chosenScope) {
                    prefs.replyScope = chosenScope
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerMenuStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosenStyle = menuStyleValues.getOrElse(position) { "both" }
                if (prefs.menuStyle != chosenStyle) {
                    prefs.menuStyle = chosenStyle
                    lifecycleScope.launch {
                        BotEngineClient.syncConfig(this@MainActivity)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        switchLockApiKey.isChecked = prefs.isApiKeyLocked
        applyApiKeyLockState(prefs.isApiKeyLocked, etGeminiApiKey, tvApiKeyLockHint)

        switchLockApiKey.setOnCheckedChangeListener { _, isLocked ->
            if (isLocked && etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
            }
            prefs.isApiKeyLocked = isLocked
            applyApiKeyLockState(isLocked, etGeminiApiKey, tvApiKeyLockHint)
            val lockToast = if (isLocked) "🔒 API Key dikunci & diamankan!" else "🔓 Kunci API Key dibuka, silakan edit."
            Toast.makeText(this, lockToast, Toast.LENGTH_SHORT).show()
        }

        btnConnectVpsNow.setOnClickListener {
            val rawHost = etVpsUrl.text.toString().trim()
            val sshUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            val sshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            val sshPass = etVpsSecret.text.toString().trim()
            if (rawHost.isEmpty()) {
                Toast.makeText(this, "Masukkan IP Public VPS terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnConnectVpsNow.isEnabled = false
            btnConnectVpsNow.text = "⏳ Menyambungkan & Memasang Bot di VPS..."
            Toast.makeText(this, "Menghubungi VPS & menyiapkan mesin bot 24 jam...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val (ok, msg) = BotEngineClient.connectAndSetupVpsFromApk(
                    this@MainActivity,
                    rawHost,
                    sshPort,
                    sshUser,
                    sshPass,
                    false
                )
                btnConnectVpsNow.isEnabled = true
                btnConnectVpsNow.text = "🔌 Sambungkan & Pasang Bot ke VPS"
                if (ok) {
                    prefs.geminiModel = modelList[spinnerGeminiModel.selectedItemPosition]
                    if (etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                        prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
                    }
                    rbModeVps.isChecked = true
                    BotEngineClient.syncConfig(this@MainActivity)
                    lastSessionsSignature = ""
                    tvEngineStatus.text = "Status: 🟢 Terhubung ke VPS (${BotEngineClient.extractHostFromUrl(rawHost)}:8765)"
                    Toast.makeText(this@MainActivity, "✅ $msg", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "❌ $msg", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnCheckVpsSsh.setOnClickListener {
            prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(etVpsUrl.text.toString())
            prefs.vpsUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            prefs.vpsSshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            prefs.vpsSecret = etVpsSecret.text.toString().trim()
            lifecycleScope.launch {
                val res = BotEngineClient.checkOrRestartVpsViaSsh(this@MainActivity, "status")
                Toast.makeText(this@MainActivity, res, Toast.LENGTH_LONG).show()
            }
        }

        btnRestartVpsSsh.setOnClickListener {
            val rawHost = etVpsUrl.text.toString().trim()
            val sshUser = etVpsUser.text.toString().trim().ifEmpty { "root" }
            val sshPort = etVpsSshPort.text.toString().trim().ifEmpty { "22" }
            val sshPass = etVpsSecret.text.toString().trim()
            prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(rawHost)
            prefs.vpsUser = sshUser
            prefs.vpsSshPort = sshPort
            prefs.vpsSecret = sshPass
            prefs.geminiModel = modelList[spinnerGeminiModel.selectedItemPosition]
            if (etGeminiApiKey.text.toString().trim().isNotEmpty()) {
                prefs.geminiApiKey = etGeminiApiKey.text.toString().trim()
            }
            Toast.makeText(this, "Memperbarui & me-restart mesin bot v4.6 di VPS via SSH...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val (ok, msg) = BotEngineClient.connectAndSetupVpsFromApk(
                    this@MainActivity,
                    rawHost,
                    sshPort,
                    sshUser,
                    sshPass,
                    true
                )
                BotEngineClient.syncConfig(this@MainActivity)
                val toastMsg = if (ok) "✅ Mesin VPS berhasil di-update ke v4.6 & di-restart: $msg" else "❌ $msg"
                Toast.makeText(this@MainActivity, toastMsg, Toast.LENGTH_LONG).show()
            }
        }

        btnPresetSantai.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah asisten AI pribadi yang asyik, ramah, dan santai di WhatsApp. Gunakan bahasa Indonesia sehari-hari yang akrab, sopan, dan to-the-point.")
            Toast.makeText(this, "Preset 'Teman Santai' diterapkan!", Toast.LENGTH_SHORT).show()
        }
        btnPresetToko.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah Customer Service & Admin Toko yang ramah, sopan, dan responsif. Bantu pelanggan dengan jelas, informatif, dan profesional.")
            Toast.makeText(this, "Preset 'Admin Toko' diterapkan!", Toast.LENGTH_SHORT).show()
        }
        btnPresetPintar.setOnClickListener {
            etSystemPrompt.setText("Kamu adalah Asisten Ahli & Riset Pintar. Jawab setiap pertanyaan dengan akurat, terstruktur, dan mudah dipahami.")
            Toast.makeText(this, "Preset 'Asisten Ahli' diterapkan!", Toast.LENGTH_SHORT).show()
        }

        startBotService()

        rgConnectionMode.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbModeVps) {
                prefs.connectionMode = "VPS"
                layoutVpsConfig.visibility = View.VISIBLE
                tvEngineStatus.text = "Status: Mode Server VPS (${prefs.vpsUrl})"
            } else {
                prefs.connectionMode = "LOCAL"
                layoutVpsConfig.visibility = View.GONE
                tvEngineStatus.text = "Status: Mesin Lokal di HP (Aktif)"
                startBotService()
            }
            lastSessionsSignature = ""
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
            }
        }

        switchMasterBot.setOnCheckedChangeListener { _, isChecked ->
            prefs.isBotEnabled = isChecked
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
            }
            val msg = if (isChecked) "Semua Bot Diaktifkan" else "Semua Bot Dijeda"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        btnSaveConfig.setOnClickListener {
            prefs.botName = etBotName.text.toString().trim().ifEmpty { "DodosBot" }
            prefs.menuStyle = menuStyleValues[spinnerMenuStyle.selectedItemPosition]
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            if (etGeminiApiKey.text.toString().trim().isNotEmpty() && !switchLockApiKey.isChecked) {
                switchLockApiKey.isChecked = true
            }
            startBotService()
            lifecycleScope.launch {
                val ok = BotEngineClient.syncConfig(this@MainActivity)
                val targetName = if (rbModeVps.isChecked) "VPS (${prefs.vpsUrl})" else "Mesin Lokal HP"
                val msg = if (ok) "✅ Konfigurasi disimpan & disinkronkan ke $targetName!" else "Konfigurasi disimpan!"
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
        }

        btnGetPairingCode.setOnClickListener {
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            val rawPhone = etPhoneNumber.text.toString().trim()
            val cleanPhone = BotEngineClient.normalizePhone(rawPhone)
            if (cleanPhone.length < 9) {
                Toast.makeText(this, "Masukkan nomor WA yang valid (contoh: 62812... atau 0812...)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val targetStr = if (prefs.connectionMode == "VPS") "VPS (${BotEngineClient.extractHostFromUrl(prefs.vpsUrl)})" else "Mesin Lokal HP"
            tvPairingCodeResult.text = "⚡ Meminta Kode dari $targetStr..."
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
                val code = BotEngineClient.requestPairingCode(this@MainActivity, cleanPhone)
                if (code.startsWith("ERROR:") || code.startsWith("GAGAL:")) {
                    tvPairingCodeResult.text = code
                } else {
                    latestPairCodeForPip = code
                    tvPairingCodeResult.text = "KODE ($cleanPhone): $code"
                    findViewById<TextView>(R.id.tvPipPairingCode)?.text = code
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("WA Pairing Code", code.replace("-", "")))
                    Toast.makeText(this@MainActivity, "✅ Kode $code otomatis disalin! Klik '🪟 Mode Jendela Kecil' untuk membuka WA.", Toast.LENGTH_LONG).show()
                }
                lastSessionsSignature = ""
            }
        }

        btnEnterPipMode.setOnClickListener {
            prefs.botName = etBotName.text.toString().trim().ifEmpty { "DodosBot" }
            startBotService()
            enterFloatingPipPairingMode()
        }

        btnCopyPairingCode.setOnClickListener {
            val raw = tvPairingCodeResult.text.toString()
            val codeOnly = raw.substringAfterLast(":").trim().replace("-", "")
            if (codeOnly.isEmpty() || codeOnly == "-" || raw.contains("ERROR") || raw.contains("GAGAL")) {
                Toast.makeText(this, "Belum ada kode pairing untuk disalin", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("WA Pairing Code", codeOnly))
            Toast.makeText(this, "Kode '$codeOnly' disalin! Tempel di WA -> Perangkat Tertaut.", Toast.LENGTH_LONG).show()
        }

        btnOpenWaWeb.setOnClickListener {
            startActivity(Intent(this, WaWebActivity::class.java))
        }

        btnDisableBatteryOpt.setOnClickListener {
            requestIgnoreBatteryOptimization()
        }

        btnTestGemini.setOnClickListener {
            saveFormToPrefs(
                rbModeVps.isChecked,
                etVpsUrl.text.toString(),
                etVpsSecret.text.toString(),
                etPhoneNumber.text.toString(),
                etGeminiApiKey.text.toString(),
                modelList[spinnerGeminiModel.selectedItemPosition],
                etSystemPrompt.text.toString(),
                scopeValues[spinnerReplyScope.selectedItemPosition],
                etGroupTrigger.text.toString(),
                etBlacklistNumbers.text.toString()
            )
            if (prefs.geminiApiKey.isEmpty()) {
                Toast.makeText(this, "Isi Gemini API Key (AQ...) terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Mengetes koneksi ke Gemini...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                BotEngineClient.syncConfig(this@MainActivity)
                val reply = BotEngineClient.callGeminiDirect(
                    prefs,
                    "test_user",
                    "Halo! Perkenalkan dirimu secara singkat dalam 1 kalimat."
                )
                if (reply != null) {
                    Toast.makeText(this@MainActivity, "✅ Sukses: $reply", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "❌ Gagal memanggil Gemini. Cek log di bawah.", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnResetMemory.setOnClickListener {
            lifecycleScope.launch {
                BotEngineClient.resetMemory(this@MainActivity)
                Toast.makeText(this@MainActivity, "Memori riwayat chat di-reset!", Toast.LENGTH_SHORT).show()
            }
        }

        lifecycleScope.launch {
            while (isActive) {
                val status = BotEngineClient.fetchStatus(this@MainActivity)
                if (BotEngineClient.appLogs.isNotEmpty()) {
                    tvLiveLogs.text = BotEngineClient.appLogs.takeLast(18).joinToString(System.lineSeparator())
                }
                val modePrefix = if (prefs.connectionMode == "VPS") "☁️ VPS (${BotEngineClient.extractHostFromUrl(prefs.vpsUrl).ifEmpty { "Belum Diisi" }})" else "📱 Lokal HP"
                if (status != null) {
                    val activeCount = status.sessions.count { it.loggedIn && it.active }
                    val totalPaired = status.sessions.size
                    if (activeCount > 0 && latestPairCodeForPip.isNotEmpty()) {
                        findViewById<TextView>(R.id.tvPipPairingCode)?.text = "✅ TERTAUT!"
                        findViewById<TextView>(R.id.tvPipStatusHint)?.text = "Nomor WA berhasil terhubung!"
                    }
                    val waConn = if (activeCount > 0) "🟢 $activeCount/$totalPaired Nomor Bot Aktif" else "🟡 $totalPaired Sesi Terdaftar"
                    tvStatsBadge.text = "📊 $modePrefix • $waConn • ${status.totalReplied} Balasan AI • ${status.activeGroups} Grup"
                    tvEngineStatus.text = "$modePrefix • $waConn"
                    renderPairedSessions(layoutPairedSessionsList, status.sessions)
                } else {
                    tvEngineStatus.text = "$modePrefix • Menunggu Koneksi Server..."
                }
                delay(2000)
            }
        }
    }

    private fun showExitOptionsDialog() {
        val options = arrayOf(
            "🟢 Keluar & Tetap Berjalan di Latar Belakang (VPS / Layanan tetap aktif)",
            "🔴 Keluar & Matikan Semua Proses di HP (Hentikan proses lokal di HP)",
            "Batal (Tetap di aplikasi)"
        )
        AlertDialog.Builder(this)
            .setTitle("Keluar dari Gemini WA Bot?")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        startBotService()
                        Toast.makeText(this, "Aplikasi ditutup. Bot tetap berjalan 24 jam!", Toast.LENGTH_SHORT).show()
                        finishAffinity()
                    }
                    1 -> {
                        Toast.makeText(this, "Mematikan layanan lokal di HP...", Toast.LENGTH_SHORT).show()
                        lifecycleScope.launch {
                            BotEngineClient.shutdownLocalEngine()
                            val stopIntent = Intent(this@MainActivity, BotForegroundService::class.java).apply {
                                action = BotForegroundService.ACTION_STOP_ALL
                            }
                            stopService(stopIntent)
                            delay(250)
                            finishAffinity()
                            exitProcess(0)
                        }
                    }
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun playWelcomeCinematicIfNeeded() {
        val shouldPlay = intent?.getBooleanExtra("play_welcome_cinematic", false) == true || !hasPlayedWelcomeThisSession
        if (!shouldPlay) return
        hasPlayedWelcomeThisSession = true
        intent?.removeExtra("play_welcome_cinematic")

        val overlay = findViewById<LinearLayout>(R.id.layoutWelcomeCinematic) ?: return
        val badge = findViewById<TextView>(R.id.tvWelcomeBadge)
        val title = findViewById<TextView>(R.id.tvWelcomeTitle)
        val subtitle = findViewById<TextView>(R.id.tvWelcomeSubtitle)
        val bar = findViewById<ProgressBar>(R.id.progressWelcomeBar)
        val statusTv = findViewById<TextView>(R.id.tvWelcomeStatus)

        overlay.visibility = View.VISIBLE
        overlay.alpha = 1f
        subtitle?.text = "COMMANDER • ${prefs.botName.uppercase()} v4.6"

        badge?.alpha = 0f
        badge?.translationY = -30f
        title?.alpha = 0f
        title?.scaleX = 0.4f
        title?.scaleY = 0.4f
        subtitle?.alpha = 0f
        subtitle?.translationY = 30f

        badge?.animate()?.alpha(1f)?.translationY(0f)?.setDuration(450)?.setInterpolator(DecelerateInterpolator())?.start()
        title?.animate()?.alpha(1f)?.scaleX(1.05f)?.scaleY(1.05f)?.setStartDelay(150)?.setDuration(650)?.setInterpolator(OvershootInterpolator(2.2f))?.withEndAction {
            title.animate().scaleX(1f).scaleY(1f).setDuration(300).start()
        }?.start()
        subtitle?.animate()?.alpha(1f)?.translationY(0f)?.setStartDelay(350)?.setDuration(500)?.setInterpolator(DecelerateInterpolator())?.start()

        lifecycleScope.launch {
            val steps = listOf(
                20 to "Memuat Sertifikat TLS & Mesin Lokal...",
                50 to "Menyiapkan 20 Banner Ekspresi Anime...",
                80 to "Mengaktifkan Video Background Loop...",
                100 to "WELCOME TO ${prefs.botName.uppercase()}!"
            )
            for ((prog, label) in steps) {
                bar?.progress = prog
                statusTv?.text = label
                delay(480)
            }
            overlay.animate()
                .alpha(0f)
                .scaleX(1.12f)
                .scaleY(1.12f)
                .setDuration(480)
                .withEndAction {
                    overlay.visibility = View.GONE
                    overlay.scaleX = 1f
                    overlay.scaleY = 1f
                }
                .start()
        }
    }

    private fun enterFloatingPipPairingMode() {
        val codeText = if (latestPairCodeForPip.isNotEmpty()) {
            latestPairCodeForPip
        } else {
            val raw = findViewById<TextView>(R.id.tvPairingCodeResult)?.text?.toString() ?: ""
            raw.substringAfterLast(":").trim().ifEmpty { "MINTA KODE DULU" }
        }
        findViewById<TextView>(R.id.tvPipPairingCode)?.text = codeText

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
                return
            } catch (e: Exception) {
                Toast.makeText(this, "Info Jendela Kecil: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val pipHud = findViewById<LinearLayout>(R.id.layoutPipMiniHud)
        if (isInPictureInPictureMode) {
            pipHud?.visibility = View.VISIBLE
        } else {
            pipHud?.visibility = View.GONE
        }
    }

    private fun applyScreenShareMode(isUnsafe: Boolean) {
        if (isUnsafe) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    setRecentsScreenshotEnabled(true)
                } catch (_: Exception) {}
            }
            markViewTreeNotSensitive(window.decorView)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun markViewTreeNotSensitive(view: View?) {
        if (view == null) return
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                // View.CONTENT_SENSITIVITY_NOT_SENSITIVE = 2 (mencegah Android 14/15 menghitamkan layar saat Share Screen WA!)
                val m = View::class.java.getMethod("setContentSensitivity", Int::class.javaPrimitiveType)
                m.invoke(view, 2)
            } catch (_: Exception) {}
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                markViewTreeNotSensitive(view.getChildAt(i))
            }
        }
    }

    private fun setupVideoBackgroundLoop(textureView: TextureView, btnAudio: Button) {
        fun updateAudioButtonLabel() {
            btnAudio.text = if (prefs.isBgMusicMuted) "🔇 Musik OFF" else "🔊 Musik ON"
        }
        updateAudioButtonLabel()

        btnAudio.setOnClickListener {
            prefs.isBgMusicMuted = !prefs.isBgMusicMuted
            val vol = if (prefs.isBgMusicMuted) 0f else 1f
            try {
                bgMediaPlayer?.setVolume(vol, vol)
            } catch (_: Exception) {}
            updateAudioButtonLabel()
        }

        textureView.isOpaque = false
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
                startBackgroundVideo(surfaceTexture, textureView, width, height)
            }
            override fun onSurfaceTextureSizeChanged(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
                adjustTextureAspectRatio(textureView, width, height)
            }
            override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
                releaseBackgroundVideo()
                return true
            }
            override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {}
        }
    }

    private fun startBackgroundVideo(surfaceTexture: SurfaceTexture, textureView: TextureView, viewW: Int, viewH: Int) {
        releaseBackgroundVideo()
        try {
            val surface = Surface(surfaceTexture)
            bgSurface = surface
            val mp = MediaPlayer()
            bgMediaPlayer = mp
            val rawId = resources.getIdentifier("bg_loop", "raw", packageName)
            if (rawId == 0) return
            val afd = resources.openRawResourceFd(rawId) ?: return
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setSurface(surface)
            mp.isLooping = true
            val vol = if (prefs.isBgMusicMuted) 0f else 1f
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener { player ->
                adjustTextureAspectRatio(textureView, viewW, viewH)
                player.start()
            }
            mp.prepareAsync()
        } catch (_: Exception) {
        }
    }

    private fun adjustTextureAspectRatio(textureView: TextureView, viewWidth: Int, viewHeight: Int) {
        val mp = bgMediaPlayer ?: return
        val videoWidth = mp.videoWidth.toFloat()
        val videoHeight = mp.videoHeight.toFloat()
        if (videoWidth <= 0f || videoHeight <= 0f || viewWidth <= 0 || viewHeight <= 0) return

        val scaleX = viewWidth.toFloat() / videoWidth
        val scaleY = viewHeight.toFloat() / videoHeight
        val maxScale = maxOf(scaleX, scaleY)

        val scaledWidth = videoWidth * maxScale
        val scaledHeight = videoHeight * maxScale

        val matrix = Matrix()
        matrix.setScale(scaledWidth / viewWidth, scaledHeight / viewHeight, viewWidth / 2f, viewHeight / 2f)
        textureView.setTransform(matrix)
    }

    private fun releaseBackgroundVideo() {
        try {
            bgMediaPlayer?.stop()
        } catch (_: Exception) {}
        try {
            bgMediaPlayer?.release()
        } catch (_: Exception) {}
        bgMediaPlayer = null
        try {
            bgSurface?.release()
        } catch (_: Exception) {}
        bgSurface = null
    }

    override fun onResume() {
        super.onResume()
        applyScreenShareMode(prefs.isUnsafeScreenShare)
        try {
            if (bgMediaPlayer != null && !bgMediaPlayer!!.isPlaying) {
                bgMediaPlayer?.start()
            }
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        try {
            if (bgMediaPlayer?.isPlaying == true) {
                bgMediaPlayer?.pause()
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        releaseBackgroundVideo()
        super.onDestroy()
    }

    private fun applyApiKeyLockState(isLocked: Boolean, etApiKey: EditText, tvHint: TextView) {
        // Gunakan inputType biasa (bukan TYPE_TEXT_VARIATION_PASSWORD) agar Android 14/15 tidak menghitamkan layar saat Share Screen!
        etApiKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (isLocked) {
            etApiKey.isEnabled = false
            etApiKey.alpha = 0.65f
            tvHint.text = "🔒 API Key terkunci aman."
            tvHint.setTextColor(Color.parseColor("#10B981"))
        } else {
            etApiKey.isEnabled = true
            etApiKey.alpha = 1.0f
            tvHint.text = "🔓 Silakan masukkan / edit API Key lalu aktifkan Kunci Key."
            tvHint.setTextColor(Color.parseColor("#94A3B8"))
        }
        markViewTreeNotSensitive(etApiKey)
    }

    private fun renderPairedSessions(container: LinearLayout, sessions: List<PairedSessionItem>) {
        val sig = sessions.joinToString("|") { "${it.id}:${it.phone}:${it.active}:${it.loggedIn}:${it.connected}:${it.state}" }
        if (sig == lastSessionsSignature) return
        lastSessionsSignature = sig

        container.removeAllViews()
        if (sessions.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "Belum ada nomor WA yang tertaut."
                setTextColor(Color.parseColor("#94A3B8"))
                textSize = 12f
                setPadding(4, 6, 4, 6)
            }
            container.addView(emptyTv)
            return
        }

        for (item in sessions) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#1E293B"))
                setPadding(20, 14, 20, 14)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = 10
                layoutParams = lp
            }

            val statusDot = when {
                item.loggedIn && item.active -> "🟢 Bot AI Aktif"
                item.loggedIn && !item.active -> "📸 Khusus Status HD (AI Mati)"
                else -> "⏳ Menunggu Kode (${item.state})"
            }

            val infoTv = TextView(this).apply {
                val phoneDisp = if (item.phone.isNotEmpty()) "+${item.phone}" else item.id
                text = "$phoneDisp\n$statusDot"
                setTextColor(Color.parseColor("#F8FAFC"))
                textSize = 12.5f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val toggleSw = SwitchMaterial(this).apply {
                isChecked = item.active
                text = if (item.active) "ON" else "OFF"
                setTextColor(Color.parseColor("#CBD5E1"))
                textSize = 11f
                setOnCheckedChangeListener { _, isChecked ->
                    text = if (isChecked) "ON" else "OFF"
                    lifecycleScope.launch {
                        BotEngineClient.toggleSessionActive(this@MainActivity, item.id, isChecked)
                        lastSessionsSignature = ""
                    }
                }
            }

            val delBtn = Button(this).apply {
                text = "Hapus"
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#EF4444"))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginStart = 12
                layoutParams = lp
                setOnClickListener {
                    lifecycleScope.launch {
                        BotEngineClient.deleteSession(this@MainActivity, item.id)
                        lastSessionsSignature = ""
                        Toast.makeText(this@MainActivity, "Nomor ${item.phone} dihapus", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            row.addView(infoTv)
            row.addView(toggleSw)
            row.addView(delBtn)
            container.addView(row)
        }
    }

    private fun saveFormToPrefs(
        isVps: Boolean,
        vpsUrl: String,
        vpsSecret: String,
        phone: String,
        apiKey: String,
        model: String,
        sysPrompt: String,
        scope: String,
        trigger: String,
        blacklist: String
    ) {
        prefs.connectionMode = if (isVps) "VPS" else "LOCAL"
        prefs.vpsUrl = BotEngineClient.formatVpsBaseUrl(vpsUrl)
        prefs.vpsSecret = vpsSecret
        prefs.phoneNumber = BotEngineClient.normalizePhone(phone)
        if (apiKey.trim().isNotEmpty()) {
            prefs.geminiApiKey = apiKey.trim()
        }
        prefs.geminiModel = model
        prefs.systemPrompt = sysPrompt
        prefs.replyScope = scope
        prefs.groupTrigger = trigger
        prefs.blacklistNumbers = blacklist
    }

    private fun startBotService() {
        val serviceIntent = Intent(this, BotForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            } else {
                Toast.makeText(this, "Aplikasi sudah bebas pembatasan baterai!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
